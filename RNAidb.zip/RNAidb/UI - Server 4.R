#####################
# Open Source Files #
#####################

# Set Working Directory (local)
#setwd('C:\\RNAidbtest\\RNAidb')
source("Load.R")  # Load libraries and data
source("UI-Tabs.R") # UI - Tab functions
#source()#R functions

##################
# User Interface #
##################

ui <- (fluidPage(theme = shinytheme("cosmo"),

  navbarPage("MosquitoRNAidb",

# About Tab function
    
   tabPanel("About",
      Aboutp()),

# The RNAi dataset

    tabPanel("RNAi Database Table",
             RNAidbp()),

  navbarMenu("Graphs & Stats",
             tabPanel("Data Explorer",
                      Explorerp()),
             tabPanel("Knockdown Graphs",
                      Knockdownp()),
             tabPanel("Publication Statistics",
                      PubsP())
             ),

# Protocol Builder
  
  navbarMenu("Protocol Builder",
    tabPanel("Browse (pre-defined protocols)",
             ProtocolBrowsep()),
    tabPanel("Build (custom protocols)",
             ProtocolCustomp())

  ),

# Downloads and Alterations

  tabPanel("Downloads and Alterations",
           DownloadsAlterationsp()
  ),

# Help

  tabPanel("Help",
           Helpp()
           )

)))

##########
# Server #
##########

source("Server-Tabs.R")

server <- (function(input, output, session){
  env_serv = environment()
  
# About Tab 
  
  Aboutp(env_serv)

# The RNAi dataset
  
  RNAidbp(env_serv)
  
# Explorer
  
  Explorerp(env_serv)
  
# Knockdown
  
  Knockdownp(env_serv)
  
# Pubs
  
  PubsP(env_serv)
  
# Help 
  
  Helpp(env_serv)

})

############
# Load App #
############

shinyApp(ui = ui, server = server)