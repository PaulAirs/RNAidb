# UI Tabs

# About Tab PAGE

Aboutp = function()

#  imageOutput("About2.png"),
  fluidPage(
  fluidRow(
    div(img(src = "About2.png", height = "145px", width = "527px"),  style="text-align: center;")),
  fluidRow(
    column(12,
    div(
      p("MosquitoRNAidb is a repository of published mosquito RNAi experiments. RNAi is an essential tool for indicuble knockdown of target genes but
              suffers from variability between studies. This site provides a resource for exploring parameters of successful and unsuccessful RNAi knockdown studies in 
              mosquito systems with the aim of generating standardized protocols for more successfull knockdown in any given experiment. Users are free to browse, search, 
              and contrast RNAi study designs and outcomes as well as create summary data, graphs, and protocol recommendations. To see the code used for this site please 
              visit ", a("Github.com/PaulAirs/RNAidb", href="https://github.com/PaulAirs/RNAidb"), "."),
      p("If you wish to add/remove/alter data on the site please see the 'Downloads and Alterations' 
        tab or contact Paul Airs at Paul.airs@gmail.com.")))))

# The RNAi dataset PAGE

RNAidbp = function()
      sidebarLayout(
      sidebarPanel(
        width = 2,  
        h4("Select Columns to show"),
        actionLink("selectall", "Select All / Reset"),
        checkboxGroupInput("show_vars", "", names(RNAidb), selected = col_list)),
        
      mainPanel("RNAi dataset",
         width = 10, 
         span(("The following data table was derived directly from published literature and contains all information pertaining to
               knockdown experiments performed on mosquito specific genes."), 
              verbatimTextOutput("LastUpdate")),
         br(),
         value = "RNAidb", DT::dataTableOutput("mytable1")))

# Explorer page

Explorerp = function()
  sidebarLayout(
    sidebarPanel(
    sliderInput('sampleSize', 'Sample Size', min = 1, max = nrow(Explorer),
            value = 500, step = 50, round = 0),
    selectInput('x', 'X', choices = nms, selected = "RNAi.trigger.length"),
    selectInput('y', 'Y', choices = nms, selected = "Knockdown.KD"),
    selectInput('color', 'Color', choices = nms, selected = "Species"),
    selectInput('facet_row', 'Facet Row', c(None = '.', nms)),
    selectInput('facet_col', 'Facet Column', c(None = '.', nms)),
    sliderInput('plotHeight', 'Height of plot (in pixels)', 
            min = 100, max = 2000, value = 1000),
    sliderInput('plotWidth', 'Width of plot (in pixels)', 
            min = 100, max = 4000, value = 1000)),
  
  mainPanel(
    plotlyOutput('trendPlot', height = "900px")))


# Graphs PAGES

Knockdownp = function()
    sidebarLayout(
    sidebarPanel(
      width = 2,
      sliderInput(inputId = "bins",
                  label = "Number of bins:",
                  min = 1,
                  max = 50,
                  value = 30)),
    mainPanel(title = "Average Knockdown vs Control", 
              div("Shown below is the average knockdown derived from all published experiments where provided"),
              plotlyOutput("distPlot")))

PubsP = function()
   sidebarLayout(
    sidebarPanel(
      width = 2),
    mainPanel(title = "Publications per year in dataset", 
              div("Shown below is the number of publications identified per year in the dataset."),
              plotlyOutput("linePubs")))
  
# Protocol Browse PAGE

ProtocolBrowsep = function()
  fluidPage(h1("Protocol Browser", align = "center"),
            h4("The Protocol Browser is a set of pre-defined RNAi protocols based on the best outcomes from selected published literature. Users can select from one of 
            these templates or use the 'Build' tool to create customize protocols. Users can use these tools to print an estimated 'best practice' protocol for future RNAi
            experiments."),
  fluidRow(
    column(12, div(style = "height:10px;background-color: gray;"))),
  fluidRow(h2("Adults", align = "center"),
    column(3, div(style = "height:80px;background-color: lightcyan;text-align:center;", h2(actionLink("Aedes1", "Aedes1")))),
    column(3, div(style = "height:80px;background-color: lightblue;text-align:center", h2(actionLink("Aedes2", "Aedes2")))),
    column(3, div(style = "height:80px;background-color: cadetblue;text-align:center", h2(actionLink("Aedes3", "Aedes3")))),
    column(3, div(style = "height:80px;background-color: darkblue;text-align:center", h2(actionLink("Aedes4", "Aedes4"))))),
  fluidRow(h2("Larvae", align = "center"),
    column(3, div(style = "height:80px;background-color: lightcyan;text-align:center;", h2(actionLink("Aedes1", "Aedes1")))),
    column(3, div(style = "height:80px;background-color: lightblue;text-align:center", h2(actionLink("Aedes2", "Aedes2")))),
    column(3, div(style = "height:80px;background-color: cadetblue;text-align:center", h2(actionLink("Aedes3", "Aedes3")))),
    column(3, div(style = "height:80px;background-color: darkblue;text-align:center", h2(actionLink("Aedes4", "Aedes4"))))),
  fluidRow(h2("Exposure", align = "center"),
    column(3, div(style = "height:80px;background-color: lightcyan;text-align:center;", h2(actionLink("Aedes1", "Aedes1")))),
    column(3, div(style = "height:80px;background-color: lightblue;text-align:center", h2(actionLink("Aedes2", "Aedes2")))),
    column(3, div(style = "height:80px;background-color: cadetblue;text-align:center", h2(actionLink("Aedes3", "Aedes3")))),
    column(3, div(style = "height:80px;background-color: darkblue;text-align:center", h2(actionLink("Aedes4", "Aedes4"))))),
  br(),
  fluidRow(
    column(12, div(style = "height:10px;background-color: gray;"))))

# Protocol Custom PAGE

ProtocolCustomp = function()
  fluidPage(
    fluidRow(
      column(12, h1("Build Custom Protocol", align = "center"),  
                  h4("The build tool allows users to custom create protocols by selecting experimental variables of interest. The tool samples the dataset 
                  and outputs summarry statistics (average, range, standard deviation, n) for each numeric variable as well as the most common feature(s) 
                  for non-numeric variables. Please note that any custom protocol will filter the dataset and overly specific protocol requests may limit output to one or a few
                  studies. For instance, selection of Geogecragius RNAi experiments using siRNA results in no possible outcome since there is only one current Georgecraigius 
                  RNAi dataset available for which the researchers used dsRNA. To enrich protocol output, any given variable can be skipped. All protocols come with a 
                  list of publications from which the protocol has been derived from, enabling users to source specific protocols of interest.")),
      fluidRow(
        column(12, strong("Step 1: Select from the following variables:"))),
        column(3, div(style = "height:100px;background-color: lightcyan;text-align:center;", h2(actionLink("Aedes1", "Aedes1")))),
        column(3, div(style = "height:100px;background-color: lightblue;text-align:center", h2(actionLink("Aedes2", "Aedes2")))),
        column(3, div(style = "height:100px;background-color: cadetblue;text-align:center", h2(actionLink("Aedes3", "Aedes3"))))))

# Downloads and Alterations

DownloadsAlterationsp = function()
  fluidPage(
    title = "Downloads and Alterations",
    p("See buttons below to download datasets, templates, and suggested alterations or removal of data entries"))
  
# Help PAGE

Helpp = function()
  tagList(
    div(h3("This section provides details of the dataset and tools available on the site.", align = "center")),
    br(),
    div(h4(style="text-align:left", "MosquitoRNAidb Background")),
    div("was originally composed as an excel database containing information
        derived from searchable literature, either directly from the text, calculated from figures, or shown as not reported (N/R).
        For information on how the literature was searched, and methods for collection of the data set please see XXX."),
    br(),
    div(h4(style="text-align:left", "Using the dataset")),
    div("The central dataset can be found in the RNAi dataset tab. It contains XXX variables and XXX current data entries. 
        Each entry is a unique RNAi experiment that is defined as a measure of gene knockdown which is different based on 
        any change in variable. Minimally; a single row equates to a single manuscript investigating a single mosquito gene 
        knockdown experiment using a single RNAi trigger, at a single dose, time-point,  strain, life-cycle stage, etc. 
        Many manuscripts contain multiple entries due to targeting multiple genes, species, tissues, doses, time-points,
         etc. While this website does not allow sophisticated manipulation of each dataset by these types, analyses have
        been performed as published in XXX."))
